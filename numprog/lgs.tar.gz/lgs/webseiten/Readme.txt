- Beide Webseitenbeispiele sind von Thomas Hutzelmann
- Das Wikipedia-Beispiel ist angelehnt an https://de.wikipedia.org/wiki/PageRank 
  (Das Ergebnis sollte sich hier ein wenig unterscheiden, da in obiger Seite die Webseiten nicht auf sich selber linken)
- Bei den Webseiten-Beispielen sollte unter Linux der Pfad zu den html-Dateien keine Großbuchstaben enthalten
- Als Start-URLs funktionieren
  file:/Pfad_zu_wiki-bsp/index.html
  file:/Pfad_zu_mini-bsp/main.html
- Den Crawler-HTML-Filter muss man für die Webseiten-Beispiele entfernen
